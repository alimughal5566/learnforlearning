<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ForStudentController extends Controller
{
    //
}

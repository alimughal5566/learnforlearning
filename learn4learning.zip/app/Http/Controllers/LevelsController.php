<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LevelsController extends Controller
{
    //
}

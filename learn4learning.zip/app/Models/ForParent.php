<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ForParent extends Model
{
    protected $fillable=['title','discription','thumbnail'];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ForStudent extends Model
{
    protected $fillable=['title','discription','thumbnail'];
}

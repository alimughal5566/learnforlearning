<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class levels extends Model
{
    //
}
